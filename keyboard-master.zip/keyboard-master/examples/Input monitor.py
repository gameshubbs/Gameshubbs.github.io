"""
Prints the scan code of all currently pressed keys.
Updates on every keyboard event.
"""
import sys
sys.path.append('..')
import keyboard

def print_pressed_keys(e):
        line = ', '.join(str(code) for code in keyboard._pressed_events)
        # '\r' and end='' overwrites the previous line.
        # ' '*40 prints 40 spaces at the end to ensure the previous line is cleared.
        line = str(line)
        print(type(line))
        line = line.replace("17", "W")
        line = line.replace("30", "A")
        line = line.replace("31", "S")
        line = line.replace("32", "D")
        line = line.replace("72", "↑")
        line = line.replace("75", "←")
        line = line.replace("80", "↓")
        line = line.replace("77", "→")
        line = line.replace("1", "Esc")
        line = line.replace("57", "space")
        print('\r' + line + ' '*40, end='')
	
keyboard.hook(print_pressed_keys)
keyboard.wait()
